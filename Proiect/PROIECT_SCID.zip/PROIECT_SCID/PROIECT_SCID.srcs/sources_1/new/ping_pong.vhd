----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/16/2025 05:22:09 PM
-- Design Name: 
-- Module Name: ping_pong - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity ping_pong is
    Port (
        clk         : in  STD_LOGIC;
        btnC       : in  STD_LOGIC;   -- reset joc
        btnL        : in  STD_LOGIC;  -- Jucator 1 (serva)
        btnR        : in  STD_LOGIC;  -- Jucator 2 (returnare)
        leds        : out STD_LOGIC_VECTOR(15 downto 0);
        seg_an      : out STD_LOGIC_VECTOR(3 downto 0);  -- anode select
        seg_cat     : out STD_LOGIC_VECTOR(6 downto 0)   -- segment catod
    );
end ping_pong;

architecture Behavioral of ping_pong is

    -- Tipuri de stare
    type StateType is (Idle, Forward, Backward, ScoreFlash);
    signal state       : StateType := Idle;

    -- LED control
    signal led_index   : INTEGER range 0 to 15 := 15;
    -- LED directie
    signal led_dir     : INTEGER := -1;  -- -1 pentru 15→0, 1 pentru 0→15

    -- Timer control
    signal clk_div     : INTEGER := 0;
    signal speed       : INTEGER := 10000000;  -- delay între pași LED

    -- Scor
    signal score_p1    : INTEGER range 0 to 99 := 0;
    signal score_p2    : INTEGER range 0 to 99 := 0;

    -- LED buffer
    -- semnal intern pentru LED-uri, initializam toate LED-urile cu 0, sa fie stinse
    signal leds_int    : STD_LOGIC_VECTOR(15 downto 0) := (others => '0');

    -- Segment display
    -- array de 4 elemente, fiecare element e integer de la 0 la 9, pentru pastrarea cifrelor care trebuie afisate pe 7 segment display
    type int_array is array (3 downto 0) of integer range 0 to 9;
    
    -- semnal bazat pe int_array de mai sus, care tine minte cifrele care trebuie afisate pe 7 segment display (initial 0)
    signal seg_val     : int_array := (others => 0);
    
    -- semnal contor care ia valori intre 0 si 3 si controleaza care dintre cele 4 display-uri este activ in acel moment
    -- asta inseamna ca aprindem pe rand cate un display la fiecare ciclu, dar suficient de repede ca sa para ca toate sunt aprinse simultan
    -- initial sunt 0, 0000 pe display
    signal seg_cnt     : INTEGER range 0 to 3 := 0;
    
    -- contor de ceas pentru a incetini rata de comutare intre cele 4 display-uri
    -- comutarea intre cifrele display-ului trebuie sa se faca mai lent decat ceasul principal
    -- daca nu am face asta, segmentul ar „clipi” prea rapid sau neregulat
    -- cand seg_clk ajunge la un prag (ex: 20000) se reseteaza si seg_cnt trece la urmatorul display
    signal seg_clk     : INTEGER := 0;

    -- Debounce
    signal btnL_sync   : STD_LOGIC := '0';
    signal btnR_sync   : STD_LOGIC := '0';

begin
    -- LED output
    leds <= leds_int;

    -- Main FSM
    process(clk)
    begin
        if rising_edge(clk) then
            -- reset
            if btnC = '1' then
                -- Resetam toate variabilele importante
                state <= Idle;
                leds_int <= (others => '0');
                led_index <= 15;
                led_dir <= -1;
                clk_div <= 0;
                speed <= 10000000;
                score_p1 <= 0;
                score_p2 <= 0;
                btnL_sync <= '0';
                btnR_sync <= '0';
            -- daca nu resetam
            else
                -- Debounce simplu
                btnL_sync <= btnL;
                btnR_sync <= btnR;

                -- Score flash timer (pauza scurta vizuala cand un jucator "rateaza mingea")
                if state = ScoreFlash then
                    -- clk_div este un contor care functioneaza ca un temporizator, la fiecare ciclu de ceas, el se mareste cu 1
                    -- cand ajunge la 100000000, inseamna ca a trecut destul timp (ex: ≈1 secunda daca ceasul este de 100 MHz), și LED-urile se sting, jocul revine in idle si mingea se reseteaza
                    if clk_div = 100000000 then
                        clk_div <= 0; -- resetam contorul
                        state <= Idle; -- trecem in starea de asteptare
                        leds_int <= (others => '0'); -- stingem LED-urile
                        led_index <= 15; -- reporneste "mingea" din dreapata
                    else
                        clk_div <= clk_div + 1; -- altfel incrementam
                    end if;

                -- daca jocul e in repaus, starea idle asteapta o actiune (serva)
                elsif state = Idle then
                    -- LED-uri stinse
                    leds_int <= (others => '0');
                    -- aprindem ultimul LED semnalizand "mingea" in pozitia de start (presupunem numaratoarea 15->0)
                    leds_int(15) <= '1';
                    -- daca jucatorul 1 apasa butonul btnL, jocul incepe
                    if btnL_sync = '1' then
                        state <= Forward;
                        -- LED-ul este activ pe pozitia 15, deci "mingea" pleaca de acolo
                        led_index <= 15;
                        -- directia este spre LED-ul 0 (15->0)
                        led_dir <= -1;
                        -- resetam contorul de timp intre pasi, e folosit pentru a crea delay intre mutarile "mingii"
                        clk_div <= 0;
                        -- se reseteaza viteza intiala a mingii, este delay-ul de asteptare intre mutarile LED-urilor, cu cat mai mic, cu atat LED-urile se misca mai rapid
                        speed <= 10000000; -- reset speed
                    end if;

                -- partea unde "mingea" se misca de la un jucator la altul, aici controlam comportamentul "mingii"
                elsif state = Forward or state = Backward then
                    -- verificam daca a trecut suficient timp (acel delay intre aprinderea LED-urilor, controlat de speed), daca nu, mai asteptam
                    if clk_div >= speed then
                        -- se reseteaza contorul de delay
                        clk_div <= 0;
                        -- LED pattern. Se sting toate LED-urile si se aprinde doar cel curent (led_index), unde este "mingea" ("miscarea mingii")
                        leds_int <= (others => '0');
                        leds_int(led_index) <= '1';

                        -- verificam daca "mingea" a ajuns la vreun capat
                        if (led_index = 0 and state = Forward) or (led_index = 15 and state = Backward) then
                            -- verificam daca jucatorul a apasat butonul la timp
                            if (state = Forward and btnR_sync = '1') or (state = Backward and btnL_sync = '1') then
                                -- daca da, crestem viteza jocului (scadem delay-ul intre aprinderea LED-urilor) doar daca speed trece de un anumit prag
                                -- daca nu am seta pragul, jocul ar deveni prea rapid
                                if speed > 2000000 then
                                    speed <= speed - 1000000;
                                end if;
                                
                                -- inversam directia "mingii"
                                if state = Forward then
                                    state <= Backward;
                                    led_index <= 0;
                                    led_dir <= 1;
                                else
                                    state <= Forward;
                                    led_index <= 15;
                                    led_dir <= -1;
                                end if;
                            else
                                -- daca butonul nu a fost apasat la timp, aprindem toate LED-urile semnalizand ca am pierdut si trecem in starea ScoreFlash pentru pauza vizuala
                                leds_int <= (others => '1');
                                state <= ScoreFlash;
                                --crestem scorul jucatorului 1 sau 2 in functie de starea in care suntem (Forward/Backward)
                                if state = Forward then
                                    score_p2 <= score_p2 + 1;
                                else
                                    score_p1 <= score_p1 + 1;
                                end if;
                            end if;
                        -- daca "mingea" nu este la unul din capate, doar o miscam in functie de directia LED-ului (led_dir, 1 sau -1)
                        else
                            led_index <= led_index + led_dir;
                        end if;
                    -- incrementam contorul pana ajunge la speed daca nu a trecut suficient timp
                    else
                        clk_div <= clk_div + 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    -- 7-segment Display (multiplexing simplu) (aprindem LED-urile pe rand, dar foarte rapid asa incat sa para ca sunt aprinse toate deodata)
    process(clk)
    begin
        if rising_edge(clk) then
            -- asteapta 20000 cicluri de ceas inainte sa comute la urmatoarea cifra de display (la 100MHz, avem 20000 x 10ns = 200us per cifra de display)
            if seg_clk = 20000 then
                seg_clk <= 0;
                -- avansam la cifra urmatoare de pe display
                seg_cnt <= (seg_cnt + 1) mod 4;

                case seg_cnt is
                    -- seg_an controleaza anodul activ (cifra selectata)
                    -- seg_val seteaza ce valoare numerica sa se afiseze la acea cifra selectata in functie de seg_cnt
                    when 0 =>
                        -- activam digit 0 pe placuta
                        seg_an <= "1110";
                        -- cifra unitatilor pentru scorul jucatorului 2
                        seg_val(3) <= score_p2 mod 10;
                    when 1 =>
                        -- activam digit 1 pe placuta
                        seg_an <= "1101";
                        -- cifra zecilor pentru scorul jucatorului 2
                        seg_val(0) <= score_p2 / 10;
                    when 2 =>
                        -- activam digit 2 pe placuta
                        seg_an <= "1011";
                        -- cifra unitatilor pentru scorul jucatorului 1
                        seg_val(1) <= score_p1 mod 10;
                    when 3 =>
                        -- activam digit 3 pe placuta
                        seg_an <= "0111";
                        -- cifra zecilor pentru scorul jucatorului 1
                        seg_val(2) <= score_p1 / 10;
                    when others =>
                        -- altfel nimic (nu ar trebui sa ajungem in acest caz)
                        null;
                end case;
            -- daca nu am numarat destule cicluri (20000), incrementam contorul
            else
                seg_clk <= seg_clk + 1;
            end if;
        end if;
    end process;

    -- 7-seg decoder, convertim valoare numerica a lui seg_val in codul pentru afisajul corect pe placuta
    -- seg_cnt - cifra curenta, seg_val(seg_cnt) - valoarea care trebuie afisata in acea pozitie
    process(seg_cnt, seg_val)
    begin
        case seg_val(seg_cnt) is
            when 0 => seg_cat <= "1000000"; -- 0
            when 1 => seg_cat <= "1111001"; -- 1
            when 2 => seg_cat <= "0100100"; -- 2
            when 3 => seg_cat <= "0110000"; -- 3
            when 4 => seg_cat <= "0011001"; -- 4
            when 5 => seg_cat <= "0010010"; -- 5
            when 6 => seg_cat <= "0000010"; -- 6
            when 7 => seg_cat <= "1111000"; -- 7
            when 8 => seg_cat <= "0000000"; -- 8
            when 9 => seg_cat <= "0010000"; -- 9
            when others => seg_cat <= "1111111"; -- altfel, toate stinse (nu ar trebui sa ajungem in acest caz)
        end case;
    end process;

end Behavioral;
